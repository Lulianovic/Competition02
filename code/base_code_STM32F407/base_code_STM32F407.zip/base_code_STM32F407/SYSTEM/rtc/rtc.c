#include "rtc.h"
#include "led.h"
#include "delay.h"
#include "usart.h"

/**
 * @brief  设置RTC时间
 * @param  hour: 小时 (0-23)
 * @param  min: 分钟 (0-59)
 * @param  sec: 秒钟 (0-59)
 * @param  ampm: 上午/下午标识
 *         @arg RTC_H12_AM: 上午
 *         @arg RTC_H12_PM: 下午
 * @retval ErrorStatus: 成功返回 SUCCESS，失败返回 ERROR
 */
ErrorStatus RTC_Set_Time(u8 hour, u8 min, u8 sec, u8 ampm)
{
    RTC_TimeTypeDef RTC_TimeTypeInitStructure;

    RTC_TimeTypeInitStructure.RTC_Hours = hour;
    RTC_TimeTypeInitStructure.RTC_Minutes = min;
    RTC_TimeTypeInitStructure.RTC_Seconds = sec;
    RTC_TimeTypeInitStructure.RTC_H12 = ampm;

    return RTC_SetTime(RTC_Format_BIN, &RTC_TimeTypeInitStructure);
}

/**
 * @brief  设置RTC日期
 * @param  year: 年份 (0-99)
 * @param  month: 月份 (1-12)
 * @param  date: 日期 (1-31)
 * @param  week: 星期 (1-7, 0为非法值)
 * @retval ErrorStatus: 成功返回 SUCCESS，失败返回 ERROR
 */
ErrorStatus RTC_Set_Date(u8 year, u8 month, u8 date, u8 week)
{
    RTC_DateTypeDef RTC_DateTypeInitStructure;
    RTC_DateTypeInitStructure.RTC_Date = date;
    RTC_DateTypeInitStructure.RTC_Month = month;
    RTC_DateTypeInitStructure.RTC_WeekDay = week;
    RTC_DateTypeInitStructure.RTC_Year = year;
    return RTC_SetDate(RTC_Format_BIN, &RTC_DateTypeInitStructure);
}

/**
 * @brief  RTC初始化函数
 * @note   配置LSE时钟源、RTC分频系数、默认时间和日期
 * @param  无
 * @retval u8: 0-初始化成功; 1-LSE开启失败; 2-进入初始化模式失败
 */
u8 My_RTC_Init(void)
{
    RTC_InitTypeDef RTC_InitStructure;
    u16 retry = 0X1FFF;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE); //使能PWR时钟
    PWR_BackupAccessCmd(ENABLE);                        //使能后备寄存器访问

    if (RTC_ReadBackupRegister(RTC_BKP_DR0) != 0x5050) //是否第一次配置?
    {
        RCC_LSEConfig(RCC_LSE_ON);                          // LSE 开启
        while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET) //检查指定的RCC标志位设置与否,等待低速晶振就绪
        {
            retry++;
            delay_ms(1);
        }
        if (retry == 0)
            return 1; // LSE 开启失败.

        RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE); //设置RTC时钟(RTCCLK),选择LSE作为RTC时钟
        RCC_RTCCLKCmd(ENABLE);                  //使能RTC时钟

        RTC_InitStructure.RTC_AsynchPrediv = 0x7F;            // RTC异步分频系数(1~0X7F)
        // RTC_InitStructure.RTC_AsynchPrediv = 1;
        RTC_InitStructure.RTC_SynchPrediv = 0xFF;             // RTC同步分频系数(0~7FFF)
        RTC_InitStructure.RTC_HourFormat = RTC_HourFormat_24; // RTC设置为,24小时格式
        RTC_Init(&RTC_InitStructure);

        RTC_Set_Time(23, 59, 56, RTC_H12_AM); //设置时间
        RTC_Set_Date(22, 5, 5, 1);            //设置日期

        RTC_WriteBackupRegister(RTC_BKP_DR0, 0x5050); //标记已经初始化过了
    }

    return 0;
}

/**
 * @brief  设置RTC闹钟A (按星期闹铃,24小时制)
 * @param  week: 星期几 (1-7)
 * @param  hour: 小时 (0-23)
 * @param  min: 分钟 (0-59)
 * @param  sec: 秒钟 (0-59)
 * @retval 无
 */
void RTC_Set_AlarmA(u8 week, u8 hour, u8 min, u8 sec)
{
    EXTI_InitTypeDef EXTI_InitStructure;
    RTC_AlarmTypeDef RTC_AlarmTypeInitStructure;
    RTC_TimeTypeDef RTC_TimeTypeInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RTC_AlarmCmd(RTC_Alarm_A, DISABLE); //关闭闹钟A

    RTC_TimeTypeInitStructure.RTC_Hours = hour;  //小时
    RTC_TimeTypeInitStructure.RTC_Minutes = min; //分钟
    RTC_TimeTypeInitStructure.RTC_Seconds = sec; //秒
    RTC_TimeTypeInitStructure.RTC_H12 = RTC_H12_AM;

    RTC_AlarmTypeInitStructure.RTC_AlarmDateWeekDay = week;                               //星期
    RTC_AlarmTypeInitStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_WeekDay; //按星期闹
    RTC_AlarmTypeInitStructure.RTC_AlarmMask = RTC_AlarmMask_None;                        //精确匹配星期，时分秒
    RTC_AlarmTypeInitStructure.RTC_AlarmTime = RTC_TimeTypeInitStructure;
    RTC_SetAlarm(RTC_Format_BIN, RTC_Alarm_A, &RTC_AlarmTypeInitStructure);

    RTC_ClearITPendingBit(RTC_IT_ALRA);  //清除RTC闹钟A的标志
    EXTI_ClearITPendingBit(EXTI_Line17); //清除LINE17上的中断标志位

    RTC_ITConfig(RTC_IT_ALRA, ENABLE); //开启闹钟A中断
    RTC_AlarmCmd(RTC_Alarm_A, ENABLE); //开启闹钟A

    EXTI_InitStructure.EXTI_Line = EXTI_Line17;            // LINE17
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;    //中断事件
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //上升沿触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;              //使能LINE17
    EXTI_Init(&EXTI_InitStructure);                        //配置

    NVIC_InitStructure.NVIC_IRQChannel = RTC_Alarm_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02; //抢占优先级1
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;        //子优先级2
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;              //使能外部中断通道
    NVIC_Init(&NVIC_InitStructure);                              //配置
}

/**
 * @brief  设置RTC周期性唤醒定时器
 * @param  wksel: 唤醒时钟源选择
 *         @arg RTC_WakeUpClock_RTCCLK_Div16: RTCCLK/16
 *         @arg RTC_WakeUpClock_RTCCLK_Div8: RTCCLK/8
 *         @arg RTC_WakeUpClock_RTCCLK_Div4: RTCCLK/4
 *         @arg RTC_WakeUpClock_RTCCLK_Div2: RTCCLK/2
 *         @arg RTC_WakeUpClock_CK_SPRE_16bits: CK_SPRE (16位)
 *         @arg RTC_WakeUpClock_CK_SPRE_17bits: CK_SPRE (17位)
 * @param  cnt: 自动重装载值 (减到0产生中断)
 * @retval 无
 */
void RTC_Set_WakeUp(u32 wksel, u16 cnt)
{
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RTC_WakeUpCmd(DISABLE); //关闭WAKE UP

    RTC_WakeUpClockConfig(wksel); //唤醒时钟选择

    RTC_SetWakeUpCounter(cnt); //设置WAKE UP自动重装载寄存器

    RTC_ClearITPendingBit(RTC_IT_WUT);   //清除RTC WAKE UP的标志
    EXTI_ClearITPendingBit(EXTI_Line22); //清除LINE22上的中断标志位

    RTC_ITConfig(RTC_IT_WUT, ENABLE); //开启WAKE UP 定时器中断
    RTC_WakeUpCmd(ENABLE);            //开启WAKE UP 定时器　

    EXTI_InitStructure.EXTI_Line = EXTI_Line22;            // LINE22
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;    //中断事件
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //上升沿触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;              //使能LINE22
    EXTI_Init(&EXTI_InitStructure);                        //配置

    NVIC_InitStructure.NVIC_IRQChannel = RTC_WKUP_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02; //抢占优先级1
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;        //子优先级2
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;              //使能外部中断通道
    NVIC_Init(&NVIC_InitStructure);                              //配置
}

/**
 * @brief  RTC闹钟A中断服务函数
 * @param  无
 * @retval 无
 */
void RTC_Alarm_IRQHandler(void)
{
    if (RTC_GetFlagStatus(RTC_FLAG_ALRAF) == SET) // ALARM A中断?
    {
        RTC_ClearFlag(RTC_FLAG_ALRAF); //清除中断标志
        printf("RTC_Alarm_IRQHandler\n");
    }
    EXTI_ClearITPendingBit(EXTI_Line17); //清除中断线17的中断标志
}

/**
 * @brief  RTC唤醒定时器中断服务函数
 * @param  无
 * @retval 无
 */
void RTC_WKUP_IRQHandler(void)
{
    if (RTC_GetFlagStatus(RTC_FLAG_WUTF) == SET)
    {
        RTC_ClearFlag(RTC_FLAG_WUTF);
    }
    EXTI_ClearITPendingBit(EXTI_Line22);
}